export interface MeridianlogyType {
  _id?: string;
  name: string;
  model3D: string[];
  videos: string[];
  headToToeOrder: number;
}
