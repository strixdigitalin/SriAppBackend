export interface Order {
  _id: string;
  planId: string;
  UserId: string;
  PaymentId: string;
  orderId: string;
  endDate: string;
  status: string;
}
